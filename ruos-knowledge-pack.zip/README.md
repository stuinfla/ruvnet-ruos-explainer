# ruos Drop-in

One zip. Two halves: a for-humans primer and a for-ai searchable knowledge base.

## What's inside

```
ruos-dropin/
  for-humans/   — read first
    ruos-primer.md         — top-down orientation: what it is, why, how it works
  for-ai/       — the searchable knowledge pack (wire this into your agent)
    ruos-kb.rvf            — single 384-dim bge-small vector DB (the "brain")
    ruos-kb.passages.jsonl — full passage text (17 passages; search returns TEXT, not {id,distance})
    ruos-kb.ids.json       — id → passage index
    ruos-symbols.json      — exact public API: every symbol + signature + doc + location
    ruos-dep-graph.json    — component dependency graph (what depends on what)
    ruos-entrypoints.json  — build/test/run/install commands + binaries
    ask-kb.mjs · kb-mcp-server.mjs · kb.config.mjs · resolve-deps.mjs · package.json
  README.md     — this file
  manifest.json — build metadata
```

## Studio (NotebookLM)
This is a **studio-less** build (INV-03): the searchable AI pack ships now; NotebookLM audio/report
media follow up later if produced. Nothing here depends on them.

## Three steps to wire the AI half in
```bash
# 1 — unzip + install (two deps, Node 18+)
unzip ruos-knowledge-pack.zip && cd ruos-dropin/for-ai && npm install

# 2 — ask the brain a question straight away
node ask-kb.mjs ruos "what does ruos actually do"

# 3 — point your AI host at it with a .mcp.json in your project root:
#   { "mcpServers": { "ruos-kb": { "command": "node", "args": ["for-ai/kb-mcp-server.mjs"] } } }
```

Built with the Repo-Primer recipe (ADR-0001 / ADR-0005). Embedder: Xenova/bge-small-en-v1.5.
